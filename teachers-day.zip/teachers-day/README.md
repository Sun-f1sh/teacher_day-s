# Happy Teachers' Day 🌸

A small, static greeting experience: Landing → Begin → Enter Name → Personalized Greeting → Replay.

No build step, no backend, no API keys — just `index.html`, `style.css`, and `script.js`.

## Run it locally

Any static file server works. From inside the `teachers-day` folder:

```bash
python3 -m http.server 5500
```

Then open `http://localhost:5500` in your browser.

(Opening `index.html` directly by double-clicking also works, since there's no backend.)

## Deploy to Vercel

**Option A — Vercel CLI**
```bash
npm i -g vercel
cd teachers-day
vercel
```
Follow the prompts (accept the defaults — Vercel auto-detects a static site). It'll give you a live `.vercel.app` link.

**Option B — Vercel dashboard**
1. Push this `teachers-day` folder to a GitHub repo.
2. Go to vercel.com → **Add New Project** → import the repo.
3. Leave the framework preset as **Other** and the build command empty — it's a static site.
4. Deploy, then copy the link it gives you.

Once deployed, share the link over WhatsApp — it opens straight into the full-screen greeting with no visible code or developer UI.
