(() => {
  "use strict";

  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const screens = {
    opening: document.getElementById("screen-opening"),
    name: document.getElementById("screen-name"),
    greeting: document.getElementById("screen-greeting"),
  };

  const beginBtn = document.getElementById("beginBtn");
  const nameForm = document.getElementById("nameForm");
  const nameInput = document.getElementById("teacherName");
  const nameError = document.getElementById("nameError");
  const greetingName = document.getElementById("greetingName");
  const greetingBody = document.getElementById("greetingBody");
  const signature = document.getElementById("signature");
  const replayBtn = document.getElementById("replayBtn");
  const musicToggle = document.getElementById("musicToggle");
  const petalField = document.getElementById("petalField");

  /* ------------------------------------------------------------------
     Screen navigation
     ------------------------------------------------------------------ */
  function goTo(screenKey) {
    Object.values(screens).forEach((el) => {
      if (!el.classList.contains("is-active")) return;
      el.classList.add("is-leaving");
      el.classList.remove("is-active");
      window.setTimeout(() => {
        el.classList.remove("is-leaving");
        el.hidden = true;
      }, prefersReducedMotion ? 0 : 550);
    });

    const target = screens[screenKey];
    target.hidden = false;
    // force reflow so the transition class re-triggers reliably
    void target.offsetWidth;
    window.setTimeout(() => {
      target.classList.add("is-active");
    }, prefersReducedMotion ? 0 : 40);
  }

  /* ------------------------------------------------------------------
     Name handling — trim and collapse whitespace only.
     We deliberately leave capitalisation exactly as the teacher typed it
     ("Prof. Sharma", "Ramesh Sir", "rita vora") since re-casing a name
     risks getting titles and honorifics wrong.
     ------------------------------------------------------------------ */
  function sanitizeName(raw) {
    return raw.replace(/\s+/g, " ").trim();
  }

  nameForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const clean = sanitizeName(nameInput.value);

    if (!clean) {
      nameError.hidden = false;
      nameInput.focus();
      nameInput.setAttribute("aria-invalid", "true");
      return;
    }

    nameError.hidden = true;
    nameInput.removeAttribute("aria-invalid");
    buildGreeting(clean);
    goTo("greeting");
  });

  nameInput.addEventListener("input", () => {
    if (!nameError.hidden) nameError.hidden = true;
  });

  beginBtn.addEventListener("click", () => {
    goTo("name");
    window.setTimeout(() => nameInput.focus(), 500);
  });

  replayBtn.addEventListener("click", () => {
    nameInput.value = "";
    goTo("opening");
  });

  /* ------------------------------------------------------------------
     Personalised greeting + word-by-word reveal
     ------------------------------------------------------------------ */
  function wrapWords(container) {
    container.querySelectorAll("p").forEach((p) => {
      const words = p.textContent.split(" ");
      p.innerHTML = words
        .map((w) => `<span class="reveal-word">${w}</span>`)
        .join(" ");
    });
  }

  function playReveal(container, baseDelayMs) {
    const words = container.querySelectorAll(".reveal-word");
    words.forEach((word, i) => {
      window.setTimeout(() => {
        word.classList.add("is-in");
      }, prefersReducedMotion ? 0 : baseDelayMs + i * 45);
    });
    return words.length;
  }

  function buildGreeting(name) {
    greetingName.textContent = name;

    // reset any previous reveal state before rebuilding
    greetingBody.innerHTML = `
      <p>Thank you for your patience, guidance, and the knowledge you&rsquo;ve shared with us.</p>
      <p>The lessons you teach don&rsquo;t end when the class does &mdash; they stay with us long after.</p>
    `;
    signature.style.opacity = prefersReducedMotion ? "1" : "0";

    wrapWords(greetingBody);
    const wordCount = playReveal(greetingBody, 500);

    const signatureDelay = 500 + wordCount * 45 + 300;
    window.setTimeout(() => {
      signature.style.transition = "opacity 0.9s ease";
      signature.style.opacity = "1";
    }, prefersReducedMotion ? 0 : signatureDelay);
  }

  /* ------------------------------------------------------------------
     Ambient petals — lightweight, generated once, CSS-driven
     ------------------------------------------------------------------ */
  function spawnPetals(count) {
    if (prefersReducedMotion) return;
    for (let i = 0; i < count; i++) {
      const petal = document.createElement("div");
      const isGold = i % 3 === 0;
      petal.className = isGold ? "petal petal--gold" : "petal";
      const left = Math.random() * 100;
      const duration = 9 + Math.random() * 8;
      const delay = Math.random() * 12;
      const drift = (Math.random() - 0.5) * 120;
      const scale = 0.6 + Math.random() * 0.8;

      petal.style.left = `${left}vw`;
      petal.style.animationDuration = `${duration}s`;
      petal.style.animationDelay = `-${delay}s`;
      petal.style.setProperty("--drift", `${drift}px`);
      petal.style.transform = `scale(${scale})`;

      petalField.appendChild(petal);
    }
  }

  spawnPetals(16);

  /* ------------------------------------------------------------------
     Optional gentle tone — generated with the Web Audio API so the page
     never needs an external audio file. Never plays automatically.
     ------------------------------------------------------------------ */
  let audioCtx = null;
  let toneNodes = null;
  let toneOn = false;

  function startTone() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    const now = audioCtx.currentTime;
    const master = audioCtx.createGain();
    master.gain.setValueAtTime(0, now);
    master.gain.linearRampToValueAtTime(0.05, now + 1.2);
    master.connect(audioCtx.destination);

    const notes = [261.63, 329.63, 392.0]; // a soft C major triad
    const oscillators = notes.map((freq, i) => {
      const osc = audioCtx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      const gain = audioCtx.createGain();
      gain.gain.value = 0.5 - i * 0.1;
      osc.connect(gain).connect(master);
      osc.start();
      return osc;
    });

    toneNodes = { master, oscillators };
  }

  function stopTone() {
    if (!toneNodes || !audioCtx) return;
    const now = audioCtx.currentTime;
    toneNodes.master.gain.linearRampToValueAtTime(0, now + 0.6);
    window.setTimeout(() => {
      toneNodes.oscillators.forEach((osc) => osc.stop());
      toneNodes = null;
    }, 650);
  }

  musicToggle.addEventListener("click", () => {
    toneOn = !toneOn;
    musicToggle.setAttribute("aria-pressed", String(toneOn));
    musicToggle.setAttribute(
      "aria-label",
      toneOn ? "Turn off gentle background tone" : "Turn on gentle background tone"
    );
    if (toneOn) {
      startTone();
    } else {
      stopTone();
    }
  });
})();
